let dados = []

function estacionarCarros() {
let modelo = document.getElementById("modelo").value
let placa = document.getElementById("placa").value
let cor = document.getElementById("cor").value
let entrada = document.getElementById("entrada").value


let objeto = {modelo: `${modelo}`, placa:`${placa}` , cor:`${cor}` , entrada:`${entrada}` }

dados.push(objeto)

console.log(dados)

}

function saidaCarro(){
    let saida = document.getElementById("saida").value
    let objeto = { saida:`${saida}`}
    if(saida){
        alert('Voce deve pagar 5 reais')
    }else if(saida > 1){
        console.log("voce deve pagar mais 2 reais")
    }

    dados.push(objeto)
    
    console.log(dados)
}


function mostrarCarros(){ 
document.getElementById("corpotabela").innerHTML = ""

dados.forEach(function(elem, index){
    let tabela = document.getElementById("corpotabela")
    let tr = document.createElement('tr')

    tr.innerHTML = `
    <tr>
        <td>${dados[index].modelo}</td>
        <td>${dados[index].placa}</td>
        <td>${dados[index].cor}</td>
        <td>${dados[index].entrada}</td>
        <td>${dados[index].saida}</td>

    </tr>
    ` 

    tabela.appendChild(tr)
});




}