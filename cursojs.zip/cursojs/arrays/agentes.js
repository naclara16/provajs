let agentes = ["Jett", "KillJoy", "Reyna", "Sage",]

for(let agente of agentes){

    if(agente == "Jett" || agente == "Reyna"){
        console.log(agente + " é um duelista")
    }else{
        console.log(agente + " é um sentinela")
    }
}