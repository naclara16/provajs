let num = [5, 8, 2, 9, 3]

//console.log(`O nosso vetor é o ${num}`)

for(let pos=0; pos < num.length; pos++){
    console.log(`a posição  ${pos} tem valor ${num[pos]}`)
}

/*let pos = num.indexOf(8)
console.log(`o valor 8 esta na posição ${pos}`)*/