function parimpar(n){
    if (n%2==0){
        return `é Par`
    }else{
       return `é Impar`
    }
}
let res = parimpar(2)
console.log(res)