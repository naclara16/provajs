function soma(n1, n2){
    return n1+n2
}

console.log(soma(2, 5))