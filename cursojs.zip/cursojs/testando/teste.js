let marvel = 50
let dc = 100

if(marvel>= 50){
    console.log("Marvel é melhor que DC")
}else if(dc>= 50){
    console.log("DC é melhor que a Marvel")
}else{
    console.log("EMPATE, nenhum é melhor que o outro")
}