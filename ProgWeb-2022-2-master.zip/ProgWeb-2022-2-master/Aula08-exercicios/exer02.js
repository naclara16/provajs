let dia = 7

switch(dia){
    case 1: console.log("1-domingo")
    break
    case 2: console.log("2-segunda")
    break
    case 3: console.log("3-terça")
    break
    case 4: console.log("4-quarta")
    break
    case 5: console.log("5-quinta")
    break
    case 6: console.log("6-sexta")
    break
    case 7: console.log("7-sabado")
    break
    default: console.log("valor inválido")
}