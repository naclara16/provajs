let letra = "a"

if(letra == "a" || letra == "e" || letra == "i" || letra == "o" || letra == "u"){
    console.log("A letra " + letra + "é uma vogal")
} else {
    console.log("A letra " + letra + "é uma consoante")
}