let base = 8
let expoente = 3
let resultado = base

for(let i = 1; i< expoente; i++){
    resultado *= base 
}

console.log(resultado)