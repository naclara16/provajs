let numero = 3

if(numero % 2 == 0){
    console.log("O número " + numero + " é ímpar")
} else {
    console.log("O número " + numero + " é par")
}