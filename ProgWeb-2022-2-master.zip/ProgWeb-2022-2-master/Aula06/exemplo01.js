console.log(Math.pow(3, 3))

console.log(Math.PI)

console.log(Math.SQRT2)

console.log(Math.sqrt(10))

// é como se fosse o módulo na matemática
console.log(Math.abs(-10.898))

console.log(Math.min(10, 43))

console.log(Math.max(59, 39))

console.log(Math.random())

// gerar número aleatório
console.log("Gerando número aleatório")
console.log(Math.floor(Math.random() * 100))

let x = Math.random() * 100
console.log(x.toFixed())

console.log(Math.floor(3.4))

console.log(Math.ceil(3.2))

