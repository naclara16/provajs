function mudaCor() {
    document.getElementById("caixa").style.backgroundColor = "blue";
}

function mudaTamanho() {
    document.getElementsByClassName("caixa2")[0].style.height = "300px";
    document.getElementsByClassName("caixa2")[0].style.width = "300px";
}

function adicionaBorda() {
    document.getElementsByTagName("section")[0].style.border = "3px solid black"
}