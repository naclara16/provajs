alert("mensagem")
confirm("Você quer realmente confirmar o processo?")
prompt("Digite seu nome: ", "Digite aqui")