let a = 15
let b = "Mensagem"
let c = a + b

console.log(typeof a)
console.log(typeof b)
console.log(typeof c)

console.log(a == b)
console.log(a == 15)
console.log(a === 15)
console.log(a != 20)
console.log(a > 20)
console.log(a < 20)
console.log(a <= 15)
console.log(a >= 15)


let d = 2
let e = 7

console.log( d > 5 && e > 5 )
console.log( d > 5 || e > 5 )

