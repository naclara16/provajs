let nome = "Jonatas"
let idade = 31

let soma = nome.length + idade

console.log("Soma da idade e nome " + soma)


for(let i = 1; i<= soma; i++){
    console.log(i + " - " + nome)
}