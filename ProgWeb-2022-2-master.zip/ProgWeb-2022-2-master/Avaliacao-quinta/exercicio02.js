let bolsonaro = 0
let lula = 31
let tebet = 20




if(bolsonaro >= 51){
    console.log("Bolsonaro ganhou no primeiro turno")
} else if(lula >= 51){
    console.log("Lula ganhou no primeiro turno")
} else if(tebet >= 51){
    console.log("Tebet ganhou no segundo turno")
} else {
    console.log("Vamos ter segundo turno")
}