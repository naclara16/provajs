let rgm = 45

if(rgm%2 == 0 && rgm>50){
    console.log("Rgm par e maior que 50")
}else if(rgm%2 == 0 && rgm<50){
    console.log("Rgm ímpar e maior que 50")
}