let nome = "Jonatas"

for (let i = 1; i<= nome.length; i++){
    console.log(i + " - " + nome);
}