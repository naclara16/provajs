
let cantores = [ "Filipe Ret", "Matuê", "Orochi", "Mc Cabelinho",
 "Tz da Coronel", "Chefin"]

 for(let cantor of cantores){
    // exemplo 01
    // console.log(cantor + " é um cantor de funk/trap")
    
    //exemplo 02
    if(cantor == "Matuê" || cantor == "Chefin" ){
        console.log(cantor + " é um cantor de trap")
        
    } else {
        console.log(cantor + " é um cantor de funk")

    }


 }